# CCTV Pro Toolkit – Phone Version V1
Open `index.html` in a browser to test the phone-first prototype.
For an installable home-screen PWA it must be hosted over HTTPS, then use the browser's Add to Home screen option.
Included: dashboard, projects, bandwidth/storage calculators, camera/alarm/IP/NVR forms, site survey, commissioning and maintenance checklists, with local browser storage.
